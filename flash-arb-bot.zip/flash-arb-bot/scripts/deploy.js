/**
 * deploy.js — Deploy FlashArb to Arbitrum One
 *
 * Usage:
 *   npx hardhat run scripts/deploy.js --network arbitrum
 *
 * After deploy, update .env:
 *   FLASH_ARB_CONTRACT=<deployed address>
 */

const { ethers } = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying from:", deployer.address);

  const balance = await deployer.getBalance();
  console.log("Balance:", ethers.utils.formatEther(balance), "ETH");

  if (balance.lt(ethers.utils.parseEther("0.002"))) {
    throw new Error("Insufficient ETH for deployment (need ~0.002 ETH on Arbitrum)");
  }

  console.log("\nDeploying FlashArb...");

  const FlashArb = await ethers.getContractFactory("FlashArb");

  // Estimate gas
  const deployTx = FlashArb.getDeployTransaction();
  const gasEstimate = await ethers.provider.estimateGas(deployTx);
  const gasPrice    = await ethers.provider.getGasPrice();
  const gasCostETH  = ethers.utils.formatEther(gasEstimate.mul(gasPrice));
  console.log(`Estimated gas: ${gasEstimate.toString()} (~${gasCostETH} ETH)`);

  const contract = await FlashArb.deploy({
    gasLimit: gasEstimate.mul(120).div(100), // +20% buffer
  });

  await contract.deployed();
  console.log("✅ FlashArb deployed:", contract.address);
  console.log("TX hash:", contract.deployTransaction.hash);

  // Verify ownership
  const owner = await contract.owner();
  console.log("Owner:", owner);
  console.log("Owner matches deployer:", owner === deployer.address);

  // Write deployment info
  const deployInfo = {
    network:    "arbitrum",
    chainId:    42161,
    address:    contract.address,
    txHash:     contract.deployTransaction.hash,
    deployer:   deployer.address,
    timestamp:  new Date().toISOString(),
    blockNumber: contract.deployTransaction.blockNumber,
  };

  const outDir = path.join(__dirname, "..", "deployments");
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(
    path.join(outDir, "arbitrum.json"),
    JSON.stringify(deployInfo, null, 2)
  );

  console.log("\n📄 Deployment saved to deployments/arbitrum.json");
  console.log("\n⚡ Update your .env:");
  console.log(`   FLASH_ARB_CONTRACT=${contract.address}`);

  // Verify on Arbiscan (if ARBISCAN_KEY set)
  if (process.env.ARBISCAN_KEY) {
    console.log("\nVerifying on Arbiscan...");
    try {
      await hre.run("verify:verify", {
        address: contract.address,
        constructorArguments: [],
      });
      console.log("✅ Verified on Arbiscan");
    } catch (e) {
      console.warn("Verification failed (may already be verified):", e.message);
    }
  }
}

main().catch((err) => {
  console.error("Deploy failed:", err);
  process.exit(1);
});
