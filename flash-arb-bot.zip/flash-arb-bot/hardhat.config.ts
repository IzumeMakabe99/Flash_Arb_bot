import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";
import "@nomicfoundation/hardhat-foundry";
import dotenv from "dotenv";
dotenv.config();

const PRIVATE_KEY    = process.env.PRIVATE_KEY    ?? "0x" + "0".repeat(64);
const RPC_URL        = process.env.RPC_URL         ?? "";
const ARBISCAN_KEY   = process.env.ARBISCAN_KEY    ?? "";

const config: HardhatUserConfig = {
  solidity: {
    version: "0.8.19",
    settings: {
      optimizer: {
        enabled: true,
        runs: 1_000_000, // Optimise for runtime (called frequently)
      },
      viaIR: true,
    },
  },

  networks: {
    hardhat: {
      forking: {
        url: RPC_URL,
        enabled: !!RPC_URL,
      },
      chainId: 42161,
    },

    arbitrum: {
      url: RPC_URL,
      accounts: [PRIVATE_KEY],
      chainId: 42161,
      gasPrice: "auto",
    },

    // Local Anvil fork
    localhost: {
      url: "http://127.0.0.1:8545",
      chainId: 42161,
    },
  },

  etherscan: {
    apiKey: {
      arbitrumOne: ARBISCAN_KEY,
    },
  },

  paths: {
    sources:   "./contracts",
    tests:     "./test",
    cache:     "./cache",
    artifacts: "./artifacts",
  },

  mocha: {
    timeout: 120_000,
  },
};

export default config;
