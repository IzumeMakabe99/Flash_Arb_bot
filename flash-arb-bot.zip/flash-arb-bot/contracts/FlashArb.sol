// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACES
// ─────────────────────────────────────────────────────────────────────────────

interface IERC20 {
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function decimals() external view returns (uint8);
}

// UniswapV3 pool for flash loans
interface IUniswapV3Pool {
    function flash(
        address recipient,
        uint256 amount0,
        uint256 amount1,
        bytes calldata data
    ) external;
    function token0() external view returns (address);
    function token1() external view returns (address);
    function fee() external view returns (uint24);
}

// UniswapV3 router (exact input single)
interface ISwapRouter {
    struct ExactInputSingleParams {
        address tokenIn;
        address tokenOut;
        uint24  fee;
        address recipient;
        uint256 deadline;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 sqrtPriceLimitX96;
    }
    function exactInputSingle(ExactInputSingleParams calldata params) external returns (uint256);

    struct ExactInputParams {
        bytes   path;
        address recipient;
        uint256 deadline;
        uint256 amountIn;
        uint256 amountOutMinimum;
    }
    function exactInput(ExactInputParams calldata params) external returns (uint256);
}

// SushiSwap V2 router
interface ISushiRouter {
    function swapExactTokensForTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external returns (uint256[] memory);
}

// UniswapV3 factory — get pool address
interface IUniswapV3Factory {
    function getPool(address tokenA, address tokenB, uint24 fee) external view returns (address pool);
}

// ─────────────────────────────────────────────────────────────────────────────
// FLASH ARB CONTRACT
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @title  FlashArb
 * @notice Production flash-arbitrage contract on Arbitrum One.
 *         Borrows via UniswapV3 flash, executes multi-hop cross-DEX arbitrage,
 *         repays the flash loan, and remits net profit to the owner.
 *
 * Supported DEXs:
 *   • Uniswap V3  (0.05%, 0.3%, 1%)
 *   • SushiSwap V2
 *   • Ramses V2 (UniV3-compatible interface)
 *
 * Security:
 *   • onlyOwner on executeArb — no external callers
 *   • Callbacks validated to come from expected UniV3 pool
 *   • Reentrancy guard
 *   • Slippage enforcement (minProfitBps)
 *   • Profit swept to owner immediately after arb
 */
contract FlashArb {

    // ─── Constants ───────────────────────────────────────────────────────────

    address public constant UNIV3_FACTORY  = 0x1F98431c8aD98523631AE4a59f267346ea31F984;
    address public constant UNIV3_ROUTER   = 0xE592427A0AEce92De3Edee1F18E0157C05861564;
    address public constant SUSHI_ROUTER   = 0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506;
    address public constant RAMSES_ROUTER  = 0xc35DADB65012eC5796536bD9864eD8773aBc74C4;

    // Known DEX identifiers packed into routers array
    address private constant SUSHI_MARKER  = 0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506;

    uint256 private constant FEE_DENOM     = 10_000;
    uint256 private constant UNIV3_FLASH_FEE_DENOM = 1_000_000;

    // ─── State ───────────────────────────────────────────────────────────────

    address public owner;
    bool    private _locked;

    /// @dev Pool address from which the current flash loan was received
    address private _flashPool;

    // ─── Events ──────────────────────────────────────────────────────────────

    event ArbExecuted(
        address indexed tokenIn,
        uint256         amountIn,
        uint256         profit
    );

    event EmergencyWithdraw(address token, uint256 amount);

    // ─── Modifiers ───────────────────────────────────────────────────────────

    modifier onlyOwner() {
        require(msg.sender == owner, "FlashArb: not owner");
        _;
    }

    modifier nonReentrant() {
        require(!_locked, "FlashArb: reentrant");
        _locked = true;
        _;
        _locked = false;
    }

    // ─── Constructor ─────────────────────────────────────────────────────────

    constructor() {
        owner = msg.sender;
    }

    // ─── Owner Functions ─────────────────────────────────────────────────────

    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "zero address");
        owner = newOwner;
    }

    /// @notice Withdraw any stuck tokens (emergency only)
    function emergencyWithdraw(address token) external onlyOwner {
        uint256 bal = IERC20(token).balanceOf(address(this));
        if (bal > 0) {
            IERC20(token).transfer(owner, bal);
            emit EmergencyWithdraw(token, bal);
        }
    }

    function emergencyWithdrawETH() external onlyOwner {
        payable(owner).transfer(address(this).balance);
    }

    // ─── Main Entry Point ────────────────────────────────────────────────────

    /**
     * @notice Execute a flash-arbitrage across up to 4 hops.
     *
     * @param path         Token addresses: [tokenIn, hop1, hop2?, tokenIn]
     * @param fees         UniV3 fee tiers per hop (0 = Sushi/AMM hop)
     * @param routers      Router address per hop
     * @param minProfitBps Minimum net profit in basis points of amountIn
     *
     * The function:
     *  1. Finds a UniV3 pool for tokenIn/path[1] to borrow from
     *  2. Calls pool.flash() — triggers uniswapV3FlashCallback
     *  3. Callback executes all swaps and repays loan+fee
     *  4. Net profit stays in contract then sent to owner
     */
    function executeArb(
        address[] calldata path,
        uint24[]  calldata fees,
        address[] calldata routers,
        uint256            minProfitBps
    ) external onlyOwner nonReentrant {
        require(path.length >= 2 && path.length <= 5,       "FlashArb: bad path len");
        require(fees.length    == path.length - 1,          "FlashArb: fees mismatch");
        require(routers.length == path.length - 1,          "FlashArb: routers mismatch");

        address tokenIn = path[0];
        uint256 flashFee = fees[0]; // fee tier to use for flash pool

        // Determine flash loan pool — try given fee tier first, fall back
        address pool = _findFlashPool(tokenIn, path[1], uint24(flashFee));
        require(pool != address(0), "FlashArb: no flash pool");

        // Decide flash loan amount — 10k USD equivalent heuristic is done off-chain.
        // Here we flash 100% of available liquidity up to a safe cap.
        // The actual amountIn is encoded in the callback data.
        // For simplicity, we flash a fixed amount; production bots compute this off-chain.
        uint256 amountToBorrow = _computeFlashAmount(pool, tokenIn);
        require(amountToBorrow > 0, "FlashArb: zero borrow");

        _flashPool = pool;

        // Pack callback data
        bytes memory data = abi.encode(path, fees, routers, minProfitBps, amountToBorrow);

        // Determine token0/token1 order in the pool
        bool isToken0 = IUniswapV3Pool(pool).token0() == tokenIn;

        IUniswapV3Pool(pool).flash(
            address(this),
            isToken0 ? amountToBorrow : 0,
            isToken0 ? 0 : amountToBorrow,
            data
        );
    }

    // ─── UniswapV3 Flash Callback ─────────────────────────────────────────────

    /**
     * @notice Called by the UniV3 pool after flash loan funds are sent.
     *         Must repay amount0 + fee0 or amount1 + fee1 by end of call.
     */
    function uniswapV3FlashCallback(
        uint256 fee0,
        uint256 fee1,
        bytes calldata data
    ) external {
        // Validate caller
        require(msg.sender == _flashPool, "FlashArb: invalid callback");

        (
            address[] memory path,
            uint24[]  memory fees,
            address[] memory routers,
            uint256          minProfitBps,
            uint256          amountBorrowed
        ) = abi.decode(data, (address[], uint24[], address[], uint256, uint256));

        address tokenIn   = path[0];
        uint256 flashFee  = fee0 > 0 ? fee0 : fee1;
        uint256 totalOwed = amountBorrowed + flashFee;

        // Execute all swaps
        uint256 amountOut = _executeSwapPath(path, fees, routers, amountBorrowed);

        // Slippage check
        uint256 minReturn = amountBorrowed + (amountBorrowed * minProfitBps / FEE_DENOM);
        require(amountOut >= minReturn, "FlashArb: insufficient profit");

        // Repay flash loan
        uint256 balBefore = IERC20(tokenIn).balanceOf(address(this));
        require(balBefore >= totalOwed, "FlashArb: cannot repay");
        IERC20(tokenIn).transfer(msg.sender, totalOwed);

        // Sweep profit to owner
        uint256 profit = IERC20(tokenIn).balanceOf(address(this));
        if (profit > 0) {
            IERC20(tokenIn).transfer(owner, profit);
            emit ArbExecuted(tokenIn, amountBorrowed, profit);
        }
    }

    // ─── Swap Execution ──────────────────────────────────────────────────────

    function _executeSwapPath(
        address[] memory path,
        uint24[]  memory fees,
        address[] memory routers,
        uint256          amountIn
    ) internal returns (uint256 amountOut) {
        uint256 currentAmount = amountIn;

        for (uint256 i = 0; i < path.length - 1; i++) {
            address tokenFrom = path[i];
            address tokenTo   = path[i + 1];
            address router    = routers[i];
            uint24  fee       = fees[i];

            // Approve router
            IERC20(tokenFrom).approve(router, currentAmount);

            if (router == SUSHI_ROUTER) {
                currentAmount = _swapSushi(tokenFrom, tokenTo, currentAmount);
            } else {
                // UniV3-compatible (Uniswap V3 or Ramses V2)
                currentAmount = _swapUniV3(router, tokenFrom, tokenTo, fee, currentAmount);
            }

            require(currentAmount > 0, "FlashArb: swap returned zero");
        }

        return currentAmount;
    }

    function _swapUniV3(
        address router,
        address tokenIn,
        address tokenOut,
        uint24  fee,
        uint256 amountIn
    ) internal returns (uint256) {
        return ISwapRouter(router).exactInputSingle(
            ISwapRouter.ExactInputSingleParams({
                tokenIn:           tokenIn,
                tokenOut:          tokenOut,
                fee:               fee,
                recipient:         address(this),
                deadline:          block.timestamp,
                amountIn:          amountIn,
                amountOutMinimum:  1, // Slippage enforced at outer level
                sqrtPriceLimitX96: 0
            })
        );
    }

    function _swapSushi(
        address tokenIn,
        address tokenOut,
        uint256 amountIn
    ) internal returns (uint256) {
        address[] memory path = new address[](2);
        path[0] = tokenIn;
        path[1] = tokenOut;

        uint256[] memory amounts = ISushiRouter(SUSHI_ROUTER).swapExactTokensForTokens(
            amountIn,
            1,
            path,
            address(this),
            block.timestamp
        );
        return amounts[amounts.length - 1];
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    function _findFlashPool(
        address tokenA,
        address tokenB,
        uint24  preferredFee
    ) internal view returns (address pool) {
        // Try preferred fee tier first
        pool = IUniswapV3Factory(UNIV3_FACTORY).getPool(tokenA, tokenB, preferredFee);
        if (pool != address(0)) return pool;

        // Fallback tiers
        uint24[3] memory fallbackFees = [uint24(500), uint24(3000), uint24(10000)];
        for (uint256 i = 0; i < fallbackFees.length; i++) {
            pool = IUniswapV3Factory(UNIV3_FACTORY).getPool(tokenA, tokenB, fallbackFees[i]);
            if (pool != address(0)) return pool;
        }

        return address(0);
    }

    function _computeFlashAmount(address pool, address token) internal view returns (uint256) {
        // Use 30% of pool liquidity to avoid excessive price impact
        uint256 poolBalance = IERC20(token).balanceOf(pool);
        uint256 amount = poolBalance * 30 / 100;
        // Hard cap at 2M USDC equivalent — tune off-chain
        uint256 cap = 2_000_000 * 1e6;
        return amount < cap ? amount : cap;
    }

    // Receive ETH if needed
    receive() external payable {}
}
