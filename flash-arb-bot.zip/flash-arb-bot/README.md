# ⚡ Flash Arb Bot — Arbitrum One

Production-ready MEV flash arbitrage bot targeting Uniswap V3, SushiSwap V2, and Ramses V2 on Arbitrum One.

## Architecture

```
Block arrives (WebSocket)
    │
    ├─ PriceScanner: quote all pairs across all DEXs in parallel
    │     ├─ UniswapV3  (0.05%, 0.3%, 1% pools)
    │     ├─ SushiSwap V2
    │     └─ Ramses V2
    │
    ├─ ArbDetector: find profitable paths
    │     ├─ Direct 2-hop  (A→B→A across different DEXs)
    │     └─ Triangular    (A→B→C→A, up to 4 hops)
    │
    ├─ GasSimulator: eth_estimateGas + eth_call pre-validation
    │     └─ Filter: net profit > $50 USD after gas
    │
    └─ BundleSubmitter
          ├─ Flashbots bundle (MEV-protected)
          └─ Direct submit fallback + auto-retry
```

## Pairs Monitored

| Pair        | DEXs               |
|-------------|-------------------|
| USDC-WETH   | V3, Sushi, Ramses |
| USDT-WETH   | V3, Sushi, Ramses |
| ARB-USDC    | V3, Sushi, Ramses |
| GMX-WETH    | V3, Sushi, Ramses |
| USDC-USDT   | V3, Sushi, Ramses |

Plus 6 triangular routes: USDC→WETH→ARB→USDC, USDC→WETH→GMX→USDC, etc.

## Quick Start

### 1. Install Dependencies

```bash
npm install
forge install foundry-rs/forge-std --no-commit
```

### 2. Configure Environment

```bash
cp .env.example .env
# Fill in: PRIVATE_KEY, RPC_URL, WS_URL
```

### 3. Compile Contracts

```bash
npm run compile        # Hardhat
npm run forge:build    # Foundry
```

### 4. Test

```bash
# Unit tests (no fork needed)
npm run forge:test

# Fork tests (requires RPC_URL)
forge test --fork-url $RPC_URL -vvv
```

### 5. Deploy Contract

```bash
npm run deploy
# Copy deployed address to .env → FLASH_ARB_CONTRACT=0x...
```

### 6. Run Bot

```bash
npm run dev     # Development (ts-node)
npm run build && npm start   # Production
```

## Configuration

| Variable | Default | Description |
|---|---|---|
| `MIN_PROFIT_USD` | 50 | Minimum net profit to execute |
| `MAX_GAS_PRICE_GWEI` | 2 | Max gas price (Arbitrum is cheap) |
| `GAS_LIMIT` | 250000 | Gas limit per TX |
| `SCAN_INTERVAL_MS` | 10000 | Fallback scan interval |
| `SLIPPAGE_BPS` | 50 | 0.5% slippage tolerance |
| `USE_MEV_BUNDLE` | true | Submit via Flashbots |

## Contract Security

- `onlyOwner` on `executeArb` — no external execution
- Callback validated against known flash pool address
- `nonReentrant` on all state-changing functions
- Slippage enforced via `minProfitBps` at contract level
- `emergencyWithdraw` for stuck funds

## Flash Loan Flow

```
executeArb()
    │
    ├─ Find UniV3 pool for token pair
    ├─ pool.flash(amount)
    │
    └─ uniswapV3FlashCallback()
          ├─ Execute swap path (UniV3 / Sushi / Ramses)
          ├─ Verify amountOut >= amountIn + fee + minProfit
          ├─ Repay pool (amountIn + flashFee)
          └─ Transfer profit to owner
```

## MEV Bundle Submission

When `USE_MEV_BUNDLE=true`, bundles are submitted to the Flashbots Arbitrum relay. The bot targets 3 consecutive blocks before giving up.

Flashbots protects against:
- Frontrunning by other searchers
- Sandwich attacks
- Failed TX fees (if bundle not included, no gas paid)

## ⚠️ Risk Warnings

1. **Smart contract risk** — Audit before deploying significant capital
2. **Market risk** — Prices move between simulation and execution
3. **Gas spikes** — Arbitrum gas can spike during congestion
4. **Competition** — Other bots compete for same opportunities
5. **Flash loan fees** — UniV3 charges 0.01%–0.3% on flash loans

## Monitoring

Logs are written to `./logs/arb-bot.log` with rotation at 10MB.

Key log patterns:
- `🔍 Found N profitable opportunities` — Scanner found opps
- `🎯 Best opp: $X.XX` — Submitting arb
- `✅ Bundle included` — Flashbots success
- `✅ TX confirmed` — Direct submit success
- `⛽ Gas too high` — Skipped due to gas spike

## License

MIT
