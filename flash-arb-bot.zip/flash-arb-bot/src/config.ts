import { ethers } from "ethers";
import dotenv from "dotenv";
dotenv.config();

// ─────────────────────────────────────────────
// NETWORK
// ─────────────────────────────────────────────
export const CHAIN_ID = 42161; // Arbitrum One

// ─────────────────────────────────────────────
// TOKENS
// ─────────────────────────────────────────────
export const TOKENS = {
  USDC: "0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8",
  WETH: "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1",
  USDT: "0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9",
  ARB:  "0x912CE59144191C1204E64559FE8253a0e49E6548",
  GMX:  "0xfc5A1A6EB076a2C7aD06eD22C90d7E710E35ad0a",
} as const;

export const TOKEN_DECIMALS: Record<string, number> = {
  [TOKENS.USDC]: 6,
  [TOKENS.WETH]: 18,
  [TOKENS.USDT]: 6,
  [TOKENS.ARB]:  18,
  [TOKENS.GMX]:  18,
};

// ─────────────────────────────────────────────
// DEX ROUTERS
// ─────────────────────────────────────────────
export const ROUTERS = {
  UNIV3:  "0xE592427A0AEce92De3Edee1F18E0157C05861564",
  SUSHI:  "0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506",
  RAMSES: "0xc35DADB65012eC5796536bD9864eD8773aBc74C4",
} as const;

// Uniswap V3 factory for pool lookups
export const UNIV3_FACTORY = "0x1F98431c8aD98523631AE4a59f267346ea31F984";
// Ramses uses same factory interface
export const RAMSES_FACTORY = "0xAA2cd7477c451E703f3B9Ba5663334914763edF8";
// SushiSwap V2 factory
export const SUSHI_FACTORY  = "0xc35DADB65012eC5796536bD9864eD8773aBc74C4";

// ─────────────────────────────────────────────
// TRADING PAIRS
// ─────────────────────────────────────────────
export interface TradePair {
  name: string;
  tokenA: string;
  tokenB: string;
}

export const PAIRS: TradePair[] = [
  { name: "USDC-WETH", tokenA: TOKENS.USDC, tokenB: TOKENS.WETH },
  { name: "USDT-WETH", tokenA: TOKENS.USDT, tokenB: TOKENS.WETH },
  { name: "ARB-USDC",  tokenA: TOKENS.ARB,  tokenB: TOKENS.USDC },
  { name: "GMX-WETH",  tokenA: TOKENS.GMX,  tokenB: TOKENS.WETH },
  { name: "USDC-USDT", tokenA: TOKENS.USDC, tokenB: TOKENS.USDT },
];

// Triangular arbitrage routes: A→B→C→A
export const TRIANGULAR_ROUTES = [
  [TOKENS.USDC, TOKENS.WETH, TOKENS.ARB,  TOKENS.USDC],
  [TOKENS.USDC, TOKENS.WETH, TOKENS.GMX,  TOKENS.USDC],
  [TOKENS.USDT, TOKENS.WETH, TOKENS.ARB,  TOKENS.USDT],
  [TOKENS.USDT, TOKENS.WETH, TOKENS.GMX,  TOKENS.USDT],
  [TOKENS.USDC, TOKENS.ARB,  TOKENS.WETH, TOKENS.USDC],
  [TOKENS.USDC, TOKENS.GMX,  TOKENS.WETH, TOKENS.USDC],
];

// ─────────────────────────────────────────────
// FEES
// ─────────────────────────────────────────────
export const FEES = {
  LOW:    500,   // 0.05% — stable pairs
  MEDIUM: 3000,  // 0.30% — standard
  HIGH:   10000, // 1.00% — exotic
} as const;

// UniV3 fee tiers to probe per pair
export const FEE_TIERS = [FEES.LOW, FEES.MEDIUM, FEES.HIGH];

// ─────────────────────────────────────────────
// BOT PARAMETERS
// ─────────────────────────────────────────────
export const MIN_PROFIT_USD   = Number(process.env.MIN_PROFIT_USD ?? 50);
export const MAX_GAS_GWEI     = Number(process.env.MAX_GAS_PRICE_GWEI ?? 2);
export const GAS_LIMIT        = Number(process.env.GAS_LIMIT ?? 250_000);
export const SCAN_INTERVAL_MS = Number(process.env.SCAN_INTERVAL_MS ?? 10_000);
export const SLIPPAGE_BPS     = Number(process.env.SLIPPAGE_BPS ?? 50);  // 0.5%
export const MAX_HOPS         = Number(process.env.MAX_HOPS ?? 4);
export const USE_MEV_BUNDLE   = process.env.USE_MEV_BUNDLE === "true";

// Chainlink price feeds (Arbitrum)
export const PRICE_FEEDS: Record<string, string> = {
  [TOKENS.WETH]: "0x639Fe6ab55C921f74e7fac1ee960C0B6293ba612",
  [TOKENS.USDC]: "0x50834F3163758fcC1Df9973b6e91f0F0F0434aD3",
  [TOKENS.ARB]:  "0xb2A824043730FE05F3DA2efaFa1CBbe83fa548D6",
  [TOKENS.GMX]:  "0xDB98056FecFff59D032aB628337A4887110df3dB",
};

// ─────────────────────────────────────────────
// RUNTIME SECRETS (validated at start)
// ─────────────────────────────────────────────
export function loadSecrets() {
  const required = ["PRIVATE_KEY", "RPC_URL", "WS_URL", "FLASH_ARB_CONTRACT"];
  for (const key of required) {
    if (!process.env[key]) throw new Error(`Missing env var: ${key}`);
  }
  return {
    privateKey:       process.env.PRIVATE_KEY!,
    rpcUrl:           process.env.RPC_URL!,
    wsUrl:            process.env.WS_URL!,
    contractAddress:  process.env.FLASH_ARB_CONTRACT!,
    flashbotsAuthKey: process.env.FLASHBOTS_AUTH_KEY ?? "",
    flashbotsRelay:   process.env.FLASHBOTS_RELAY_URL ?? "https://relay.flashbots.net",
  };
}
