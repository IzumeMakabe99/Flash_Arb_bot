/**
 * Flash Arbitrage Bot — Arbitrum One
 * Scans → Simulates → Bundles → Submits MEV bundles
 *
 * Architecture:
 *  1. PriceScanner  — fetches on-chain quotes from UniV3, Sushi, Ramses
 *  2. ArbDetector   — finds profitable paths (direct + triangular)
 *  3. GasSimulator  — eth_estimateGas + eth_call simulation pre-submission
 *  4. BundleSubmitter — builds Flashbots bundle and submits to relay
 *  5. NonceManager  — thread-safe nonce tracking with auto-retry
 */

import { ethers, BigNumber } from "ethers";
import { FlashbotsBundleProvider } from "@flashbots/ethers-provider-bundle";
import dotenv from "dotenv";
import winston from "winston";
import fs from "fs";
import path from "path";

import {
  loadSecrets,
  TOKENS,
  TOKEN_DECIMALS,
  ROUTERS,
  PAIRS,
  TRIANGULAR_ROUTES,
  FEE_TIERS,
  FEES,
  MIN_PROFIT_USD,
  MAX_GAS_GWEI,
  GAS_LIMIT,
  SCAN_INTERVAL_MS,
  SLIPPAGE_BPS,
  USE_MEV_BUNDLE,
  PRICE_FEEDS,
  UNIV3_FACTORY,
  SUSHI_FACTORY,
} from "./config";

dotenv.config();

// ─────────────────────────────────────────────
// LOGGER
// ─────────────────────────────────────────────
const logsDir = path.join(process.cwd(), "logs");
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL ?? "info",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message }) =>
      `[${timestamp}] ${level.toUpperCase()} ${message}`
    )
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({
      filename: process.env.LOG_FILE ?? "./logs/arb-bot.log",
      maxsize: 10 * 1024 * 1024, // 10 MB rotate
      maxFiles: 5,
    }),
  ],
});

// ─────────────────────────────────────────────
// ABIs (minimal)
// ─────────────────────────────────────────────
const ERC20_ABI = [
  "function decimals() view returns (uint8)",
  "function balanceOf(address) view returns (uint256)",
];

const UNIV3_QUOTER_ABI = [
  "function quoteExactInputSingle(address tokenIn,address tokenOut,uint24 fee,uint256 amountIn,uint160 sqrtPriceLimitX96) returns (uint256 amountOut)",
];

const UNIV3_FACTORY_ABI = [
  "function getPool(address,address,uint24) view returns (address)",
];

const SUSHI_ROUTER_ABI = [
  "function getAmountsOut(uint256 amountIn, address[] path) view returns (uint256[] amounts)",
];

const CHAINLINK_ABI = [
  "function latestRoundData() view returns (uint80,int256,uint256,uint256,uint80)",
];

const FLASH_ARB_ABI = [
  `function executeArb(
      address[] calldata path,
      uint24[]  calldata fees,
      address[] calldata routers,
      uint256           minProfitBps
  ) external`,
  "function owner() view returns (address)",
  "event ArbExecuted(address indexed tokenIn,uint256 amountIn,uint256 profit)",
];

// Uniswap V3 Quoter (same on Arbitrum)
const UNIV3_QUOTER = "0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6";

// ─────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────
interface ArbOpportunity {
  path: string[];
  fees: number[];
  routers: string[];
  amountIn: BigNumber;
  expectedProfit: BigNumber;  // in USD (6-decimal USDC)
  profitUSD: number;
  gasEstimate: BigNumber;
  netProfitUSD: number;
}

// ─────────────────────────────────────────────
// NONCE MANAGER
// ─────────────────────────────────────────────
class NonceManager {
  private nonce: number | null = null;
  private pending = 0;

  constructor(private wallet: ethers.Wallet) {}

  async getNext(): Promise<number> {
    if (this.nonce === null) {
      this.nonce = await this.wallet.getTransactionCount("pending");
    }
    const n = this.nonce + this.pending;
    this.pending++;
    return n;
  }

  confirm() {
    if (this.pending > 0) this.pending--;
    if (this.nonce !== null) this.nonce++;
  }

  async reset() {
    this.nonce = await this.wallet.getTransactionCount("pending");
    this.pending = 0;
  }
}

// ─────────────────────────────────────────────
// PRICE ORACLE (Chainlink)
// ─────────────────────────────────────────────
class PriceOracle {
  private cache: Map<string, { price: number; ts: number }> = new Map();
  private readonly TTL = 60_000; // 60s cache

  constructor(private provider: ethers.providers.Provider) {}

  async getUSDPrice(token: string): Promise<number> {
    const cached = this.cache.get(token);
    if (cached && Date.now() - cached.ts < this.TTL) return cached.price;

    const feed = PRICE_FEEDS[token];
    if (!feed) {
      // Stablecoins default to $1
      if (token === TOKENS.USDC || token === TOKENS.USDT) return 1.0;
      return 0;
    }

    try {
      const contract = new ethers.Contract(feed, CHAINLINK_ABI, this.provider);
      const [, answer] = await contract.latestRoundData();
      const price = Number(answer) / 1e8; // Chainlink 8-decimal
      this.cache.set(token, { price, ts: Date.now() });
      return price;
    } catch {
      return 0;
    }
  }

  /** Convert token amount to USD */
  async toUSD(token: string, amount: BigNumber): Promise<number> {
    const price = await this.getUSDPrice(token);
    const decimals = TOKEN_DECIMALS[token] ?? 18;
    return (Number(amount) / 10 ** decimals) * price;
  }
}

// ─────────────────────────────────────────────
// DEX QUOTERS
// ─────────────────────────────────────────────
async function quoteUniV3(
  provider: ethers.providers.Provider,
  tokenIn: string,
  tokenOut: string,
  fee: number,
  amountIn: BigNumber
): Promise<BigNumber | null> {
  try {
    const quoter = new ethers.Contract(UNIV3_QUOTER, UNIV3_QUOTER_ABI, provider);
    const out = await quoter.callStatic.quoteExactInputSingle(
      tokenIn, tokenOut, fee, amountIn, 0
    );
    return out as BigNumber;
  } catch {
    return null;
  }
}

async function quoteSushiV2(
  provider: ethers.providers.Provider,
  tokenIn: string,
  tokenOut: string,
  amountIn: BigNumber
): Promise<BigNumber | null> {
  try {
    const router = new ethers.Contract(ROUTERS.SUSHI, SUSHI_ROUTER_ABI, provider);
    const amounts = await router.getAmountsOut(amountIn, [tokenIn, tokenOut]);
    return amounts[1] as BigNumber;
  } catch {
    return null;
  }
}

// Ramses uses Uniswap V3 router/quoter interface
async function quoteRamses(
  provider: ethers.providers.Provider,
  tokenIn: string,
  tokenOut: string,
  fee: number,
  amountIn: BigNumber
): Promise<BigNumber | null> {
  // Ramses quoter (same interface as UniV3)
  const RAMSES_QUOTER = "0xAA2cd7477c451E703f3B9Ba5663334914763edF8";
  try {
    const quoter = new ethers.Contract(RAMSES_QUOTER, UNIV3_QUOTER_ABI, provider);
    const out = await quoter.callStatic.quoteExactInputSingle(
      tokenIn, tokenOut, fee, amountIn, 0
    );
    return out as BigNumber;
  } catch {
    return null;
  }
}

// ─────────────────────────────────────────────
// BEST QUOTE AGGREGATOR
// ─────────────────────────────────────────────
interface QuoteResult {
  amountOut: BigNumber;
  router: string;
  fee: number;
}

async function getBestQuote(
  provider: ethers.providers.Provider,
  tokenIn: string,
  tokenOut: string,
  amountIn: BigNumber
): Promise<QuoteResult | null> {
  const promises: Promise<QuoteResult | null>[] = [];

  // UniV3 — probe all fee tiers
  for (const fee of FEE_TIERS) {
    promises.push(
      quoteUniV3(provider, tokenIn, tokenOut, fee, amountIn).then((out) =>
        out ? { amountOut: out, router: ROUTERS.UNIV3, fee } : null
      )
    );
  }

  // Sushi V2
  promises.push(
    quoteSushiV2(provider, tokenIn, tokenOut, amountIn).then((out) =>
      out ? { amountOut: out, router: ROUTERS.SUSHI, fee: 0 } : null
    )
  );

  // Ramses V2
  for (const fee of [FEES.LOW, FEES.MEDIUM]) {
    promises.push(
      quoteRamses(provider, tokenIn, tokenOut, fee, amountIn).then((out) =>
        out ? { amountOut: out, router: ROUTERS.RAMSES, fee } : null
      )
    );
  }

  const results = await Promise.allSettled(promises);
  let best: QuoteResult | null = null;

  for (const r of results) {
    if (r.status === "fulfilled" && r.value) {
      if (!best || r.value.amountOut.gt(best.amountOut)) {
        best = r.value;
      }
    }
  }

  return best;
}

// ─────────────────────────────────────────────
// ARB DETECTOR — DIRECT 2-HOP
// ─────────────────────────────────────────────
async function detectDirectArb(
  provider: ethers.providers.Provider,
  oracle: PriceOracle,
  tokenA: string,
  tokenB: string,
  amountInUSD: number
): Promise<ArbOpportunity | null> {
  const tokenAPrice = await oracle.getUSDPrice(tokenA);
  if (tokenAPrice === 0) return null;

  const decimalsA = TOKEN_DECIMALS[tokenA] ?? 18;
  const amountIn = ethers.utils.parseUnits(
    (amountInUSD / tokenAPrice).toFixed(decimalsA),
    decimalsA
  );

  // Forward: A → B on best DEX 1, then B → A on best DEX 2
  const [q1, q2] = await Promise.all([
    getBestQuote(provider, tokenA, tokenB, amountIn),
    getBestQuote(provider, tokenA, tokenB, amountIn), // placeholder — will use q1.out below
  ]);

  if (!q1) return null;

  const q2b = await getBestQuote(provider, tokenB, tokenA, q1.amountOut);
  if (!q2b) return null;

  const amountOut = q2b.amountOut;

  if (amountOut.lte(amountIn)) return null;

  const profitRaw = amountOut.sub(amountIn);
  const profitUSD = await oracle.toUSD(tokenA, profitRaw);

  if (profitUSD < MIN_PROFIT_USD * 0.5) return null; // quick filter before gas sim

  return {
    path:    [tokenA, tokenB, tokenA],
    fees:    [q1.fee, q2b.fee],
    routers: [q1.router, q2b.router],
    amountIn,
    expectedProfit: profitRaw,
    profitUSD,
    gasEstimate: BigNumber.from(0),
    netProfitUSD: 0,
  };
}

// ─────────────────────────────────────────────
// ARB DETECTOR — TRIANGULAR 3-HOP
// ─────────────────────────────────────────────
async function detectTriangularArb(
  provider: ethers.providers.Provider,
  oracle: PriceOracle,
  route: string[],
  amountInUSD: number
): Promise<ArbOpportunity | null> {
  const tokenIn = route[0];
  const tokenInPrice = await oracle.getUSDPrice(tokenIn);
  if (tokenInPrice === 0) return null;

  const decimals = TOKEN_DECIMALS[tokenIn] ?? 18;
  let amount = ethers.utils.parseUnits(
    (amountInUSD / tokenInPrice).toFixed(decimals),
    decimals
  );

  const fees: number[] = [];
  const routers: string[] = [];

  for (let i = 0; i < route.length - 1; i++) {
    const q = await getBestQuote(provider, route[i], route[i + 1], amount);
    if (!q) return null;
    amount = q.amountOut;
    fees.push(q.fee);
    routers.push(q.router);
  }

  const tokenInAmt = ethers.utils.parseUnits(
    (amountInUSD / tokenInPrice).toFixed(decimals),
    decimals
  );

  if (amount.lte(tokenInAmt)) return null;

  const profitRaw = amount.sub(tokenInAmt);
  const profitUSD = await oracle.toUSD(tokenIn, profitRaw);

  if (profitUSD < MIN_PROFIT_USD * 0.5) return null;

  return {
    path: route,
    fees,
    routers,
    amountIn: tokenInAmt,
    expectedProfit: profitRaw,
    profitUSD,
    gasEstimate: BigNumber.from(0),
    netProfitUSD: 0,
  };
}

// ─────────────────────────────────────────────
// GAS SIMULATOR
// ─────────────────────────────────────────────
async function simulateAndEnrich(
  provider: ethers.providers.Provider,
  wallet: ethers.Wallet,
  contract: ethers.Contract,
  oracle: PriceOracle,
  opp: ArbOpportunity
): Promise<ArbOpportunity | null> {
  try {
    // eth_estimateGas simulation
    const gasEstimate = await contract.estimateGas.executeArb(
      opp.path,
      opp.fees,
      opp.routers,
      SLIPPAGE_BPS,
      { from: wallet.address }
    );

    const gasPrice = await provider.getGasPrice();
    const gasCostWei = gasEstimate.mul(gasPrice);
    const gasCostUSD = await oracle.toUSD(TOKENS.WETH, gasCostWei);

    const netProfitUSD = opp.profitUSD - gasCostUSD;

    if (netProfitUSD < MIN_PROFIT_USD) {
      logger.debug(
        `Opp filtered: gross $${opp.profitUSD.toFixed(2)}, gas $${gasCostUSD.toFixed(2)}, net $${netProfitUSD.toFixed(2)}`
      );
      return null;
    }

    return {
      ...opp,
      gasEstimate,
      netProfitUSD,
    };
  } catch (err: any) {
    logger.debug(`Simulation reverted: ${err.message?.slice(0, 80)}`);
    return null;
  }
}

// ─────────────────────────────────────────────
// BUNDLE BUILDER & SUBMITTER
// ─────────────────────────────────────────────
async function submitBundle(
  provider: ethers.providers.JsonRpcProvider,
  flashbotsProvider: FlashbotsBundleProvider | null,
  wallet: ethers.Wallet,
  nonceManager: NonceManager,
  contract: ethers.Contract,
  opp: ArbOpportunity
): Promise<boolean> {
  const nonce = await nonceManager.getNext();
  const gasPrice = await provider.getGasPrice();

  // Cap gas price
  const maxGasPrice = ethers.utils.parseUnits(String(MAX_GAS_GWEI), "gwei");
  if (gasPrice.gt(maxGasPrice)) {
    logger.warn(`Gas price too high: ${ethers.utils.formatUnits(gasPrice, "gwei")} gwei`);
    nonceManager.reset();
    return false;
  }

  const txData = await contract.populateTransaction.executeArb(
    opp.path,
    opp.fees,
    opp.routers,
    SLIPPAGE_BPS
  );

  const tx: ethers.providers.TransactionRequest = {
    ...txData,
    nonce,
    gasLimit: opp.gasEstimate.mul(110).div(100), // +10% buffer
    gasPrice: gasPrice.mul(110).div(100),         // +10% tip
    chainId: 42161,
  };

  if (USE_MEV_BUNDLE && flashbotsProvider) {
    return submitFlashbotsBundle(flashbotsProvider, wallet, tx, opp);
  } else {
    return submitDirect(wallet, tx, nonceManager);
  }
}

async function submitFlashbotsBundle(
  flashbotsProvider: FlashbotsBundleProvider,
  wallet: ethers.Wallet,
  tx: ethers.providers.TransactionRequest,
  opp: ArbOpportunity
): Promise<boolean> {
  const MAX_BLOCKS = 3;

  try {
    const blockNumber = await wallet.provider!.getBlockNumber();

    for (let i = 1; i <= MAX_BLOCKS; i++) {
      const targetBlock = blockNumber + i;

      const bundle = [{ signer: wallet, transaction: tx }];

      const simulation = await flashbotsProvider.simulate(bundle, targetBlock);
      if ("error" in simulation) {
        logger.error(`Flashbots sim error: ${simulation.error.message}`);
        return false;
      }

      const resp = await flashbotsProvider.sendBundle(bundle, targetBlock);
      if ("error" in resp) {
        logger.error(`Bundle send error: ${(resp as any).error}`);
        continue;
      }

      const waitResp = await (resp as any).wait();
      if (waitResp === 0) {
        logger.info(
          `✅ Bundle included block ${targetBlock} | path ${opp.path.join("→")} | net $${opp.netProfitUSD.toFixed(2)}`
        );
        return true;
      }

      logger.debug(`Bundle not included in block ${targetBlock}, retrying...`);
    }

    logger.warn("Bundle not included in any target block");
    return false;
  } catch (err: any) {
    logger.error(`Flashbots error: ${err.message}`);
    return false;
  }
}

async function submitDirect(
  wallet: ethers.Wallet,
  tx: ethers.providers.TransactionRequest,
  nonceManager: NonceManager
): Promise<boolean> {
  const MAX_RETRIES = 3;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const sent = await wallet.sendTransaction(tx);
      logger.info(`📤 TX sent: ${sent.hash} (attempt ${attempt})`);

      const receipt = await sent.wait(1);
      if (receipt.status === 1) {
        logger.info(`✅ TX confirmed: ${sent.hash} | block ${receipt.blockNumber}`);
        nonceManager.confirm();
        return true;
      } else {
        logger.error(`TX reverted: ${sent.hash}`);
        await nonceManager.reset();
        return false;
      }
    } catch (err: any) {
      if (err.code === "NONCE_EXPIRED" || err.message?.includes("nonce")) {
        logger.warn("Nonce conflict, resetting...");
        await nonceManager.reset();
        tx = { ...tx, nonce: await nonceManager.getNext() };
      } else {
        logger.error(`TX error (attempt ${attempt}): ${err.message}`);
        if (attempt === MAX_RETRIES) return false;
        await sleep(1000 * attempt);
      }
    }
  }
  return false;
}

// ─────────────────────────────────────────────
// SCANNER LOOP
// ─────────────────────────────────────────────
async function scanOnce(
  provider: ethers.providers.Provider,
  wallet: ethers.Wallet,
  oracle: PriceOracle,
  contract: ethers.Contract,
  opportunities: ArbOpportunity[]
): Promise<void> {
  const AMOUNT_USD = 10_000; // Flash loan size in USD equivalent

  const tasks: Promise<ArbOpportunity | null>[] = [];

  // Direct 2-hop arbs
  for (const pair of PAIRS) {
    tasks.push(detectDirectArb(provider, oracle, pair.tokenA, pair.tokenB, AMOUNT_USD));
  }

  // Triangular arbs
  for (const route of TRIANGULAR_ROUTES) {
    tasks.push(detectTriangularArb(provider, oracle, route, AMOUNT_USD));
  }

  const rawOpps = (await Promise.allSettled(tasks))
    .filter((r) => r.status === "fulfilled" && r.value !== null)
    .map((r) => (r as PromiseFulfilledResult<ArbOpportunity>).value);

  // Simulate and filter
  const simTasks = rawOpps.map((opp) =>
    simulateAndEnrich(provider, wallet, contract, oracle, opp)
  );

  const simResults = (await Promise.allSettled(simTasks))
    .filter((r) => r.status === "fulfilled" && r.value !== null)
    .map((r) => (r as PromiseFulfilledResult<ArbOpportunity>).value);

  for (const opp of simResults) {
    opportunities.push(opp);
  }

  if (simResults.length > 0) {
    logger.info(`🔍 Found ${simResults.length} profitable opportunities`);
  }
}

// ─────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────
async function main() {
  logger.info("🚀 Flash Arb Bot starting — Arbitrum One");

  const secrets = loadSecrets();

  // Providers
  const httpProvider = new ethers.providers.JsonRpcProvider(secrets.rpcUrl, 42161);
  const wsProvider   = new ethers.providers.WebSocketProvider(secrets.wsUrl, 42161);

  const wallet = new ethers.Wallet(secrets.privateKey, httpProvider);
  logger.info(`Wallet: ${wallet.address}`);

  const contract = new ethers.Contract(secrets.contractAddress, FLASH_ARB_ABI, wallet);
  const oracle   = new PriceOracle(httpProvider);
  const nonces   = new NonceManager(wallet);

  // Flashbots provider (optional)
  let flashbotsProvider: FlashbotsBundleProvider | null = null;
  if (USE_MEV_BUNDLE && secrets.flashbotsAuthKey) {
    try {
      const fbWallet = new ethers.Wallet(secrets.flashbotsAuthKey);
      flashbotsProvider = await FlashbotsBundleProvider.create(
        httpProvider,
        fbWallet,
        secrets.flashbotsRelay,
        "arbitrum"
      );
      logger.info("✅ Flashbots provider ready");
    } catch (err: any) {
      logger.warn(`Flashbots init failed: ${err.message} — falling back to direct submit`);
    }
  }

  // Listen to contract events
  contract.on("ArbExecuted", (tokenIn, amountIn, profit) => {
    logger.info(`🎉 ArbExecuted — token: ${tokenIn} profit: ${profit}`);
  });

  let scanning = false;
  let scanCount = 0;

  // WebSocket new-block trigger
  wsProvider.on("block", async (blockNumber: number) => {
    if (scanning) return;
    scanning = true;
    scanCount++;

    try {
      logger.debug(`📦 Block ${blockNumber} | scan #${scanCount}`);

      const opportunities: ArbOpportunity[] = [];
      await scanOnce(httpProvider, wallet, oracle, contract, opportunities);

      if (opportunities.length === 0) {
        scanning = false;
        return;
      }

      // Sort by net profit descending
      opportunities.sort((a, b) => b.netProfitUSD - a.netProfitUSD);
      const best = opportunities[0];

      logger.info(
        `🎯 Best opp: $${best.netProfitUSD.toFixed(2)} | path: ${best.path.join("→")} | routers: ${best.routers.join(",")}`
      );

      const gasPrice = await httpProvider.getGasPrice();
      const maxGas   = ethers.utils.parseUnits(String(MAX_GAS_GWEI), "gwei");

      if (gasPrice.gt(maxGas)) {
        logger.warn(`⛽ Gas too high (${ethers.utils.formatUnits(gasPrice, "gwei")} gwei), skipping`);
        scanning = false;
        return;
      }

      const success = await submitBundle(
        httpProvider,
        flashbotsProvider,
        wallet,
        nonces,
        contract,
        best
      );

      if (!success) logger.warn("Submission failed, will retry next block");
    } catch (err: any) {
      logger.error(`Scan error: ${err.message}`);
    } finally {
      scanning = false;
    }
  });

  // Fallback interval scan (if WebSocket misses blocks)
  setInterval(async () => {
    if (!scanning) {
      const blockNumber = await httpProvider.getBlockNumber();
      wsProvider.emit("block", blockNumber);
    }
  }, SCAN_INTERVAL_MS);

  logger.info(`✅ Bot running | scan every ${SCAN_INTERVAL_MS / 1000}s | min profit $${MIN_PROFIT_USD}`);

  // Graceful shutdown
  for (const sig of ["SIGINT", "SIGTERM"]) {
    process.on(sig, () => {
      logger.info("Shutting down...");
      wsProvider.removeAllListeners();
      process.exit(0);
    });
  }
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

main().catch((err) => {
  logger.error(`Fatal: ${err.message}`);
  process.exit(1);
});
